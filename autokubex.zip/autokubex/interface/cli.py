import typer
from k8s_connector.cluster_connector import load_cluster
from ai_engine.planner import diagnose_cluster

app = typer.Typer()

@app.command()
def connect(cluster_config: str):
    """Connect to a Kubernetes cluster using kubeconfig path."""
    load_cluster(cluster_config)

@app.command()
def diagnose():
    """Run diagnosis using AI engine."""
    result = diagnose_cluster()
    typer.echo(result)