import streamlit as st
from ai_engine.planner import diagnose_cluster
from k8s_connector.kube_api import get_pod_issues

st.set_page_config(page_title="AutoKubeX Dashboard", layout="wide")
st.title("🤖 AutoKubeX – AI K8s Manager")

if st.button("Run Cluster Diagnosis"):
    result = diagnose_cluster()
    st.code(result, language="yaml")

st.subheader("Current Unhealthy Pods")
issues = get_pod_issues()
if issues:
    for ns, pod in issues:
        st.warning(f"{ns}/{pod}")
else:
    st.success("All pods are healthy")