# k8s_connector/cluster_connector.py
from kubernetes import config

def load_cluster(kubeconfig_path: str):
    config.load_kube_config(config_file=kubeconfig_path)
    print(f"[+] Connected to cluster using {kubeconfig_path}")
