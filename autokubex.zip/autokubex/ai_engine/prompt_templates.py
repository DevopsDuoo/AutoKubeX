BASE_DIAGNOSIS_TEMPLATE = """
Analyze the following Kubernetes cluster status and list any critical issues or recommendations:

{cluster_state}
"""